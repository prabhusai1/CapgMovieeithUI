package com.capgemini.employeeapp.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.employeeapp.exception.EmployeeNotFoundException;
import com.capgemini.employeeapp.model.Employee;
import com.capgemini.employeeapp.repository.EmployeeRepository;
import com.capgemini.employeeapp.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employee addNewEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	public Employee findEmployeeById(int employeeId) throws EmployeeNotFoundException {
		Optional<Employee> data = employeeRepository.findById(employeeId);
		if (data.isPresent())
			return data.get();

		throw new EmployeeNotFoundException("Employee ID not Found");
	}

	@Override
	public List<Employee> findAllEmployees() {
		return employeeRepository.findAll();
	}

}
