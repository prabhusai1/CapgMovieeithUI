package com.capgemini.employeeapp.service;

import java.util.List;

import com.capgemini.employeeapp.exception.EmployeeNotFoundException;
import com.capgemini.employeeapp.model.Employee;

public interface EmployeeService {

	public Employee addNewEmployee(Employee employee);

	public Employee findEmployeeById(int employeeId) throws EmployeeNotFoundException;

	public List<Employee> findAllEmployees();
}
