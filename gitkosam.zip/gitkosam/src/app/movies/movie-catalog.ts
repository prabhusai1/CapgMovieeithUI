import { Movie } from './movie';

export class CatalogItem {
    movie: Movie;
    rating: number;
}

export class MovieCatalog {
    catalogItems: [CatalogItem];
}