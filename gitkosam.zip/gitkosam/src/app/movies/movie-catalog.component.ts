import { Component } from '@angular/core';
import { MovieCatalog } from './movie-catalog';
import { MovieService } from './movie.service';

@Component({
    templateUrl: "./movie-catalog.component.html"
})
export class MovieCatalogComponent {
    userId: string;
    movieCatalog: MovieCatalog;
    constructor(private movieService: MovieService) { }
    getMovieCatalog() {
        //console.log(this.userId);
        this.movieService.getMovieCatalog(this.userId).subscribe((data: MovieCatalog) => {
            console.log(data);

            this.movieCatalog = data;
        }
        )
    }
}