import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MovieCatalog } from './movie-catalog';
import { Movie } from './movie';

@Injectable({
    providedIn: "root"
})

export class MovieService {

    baseUrl = "http://localhost:9000/";
    constructor(private http: HttpClient) { }

    getMovieCatalog(userId: string): Observable<MovieCatalog> {
        return this.http.get<MovieCatalog>
            (this.baseUrl + "moviecatalog/catalog/" + userId);
    }


    getMovieById(movieId: number): Observable<Movie> {
        return this.http.get<Movie>(
            this.baseUrl + "movieservice/movies/" + movieId);
    }

    getNoOfMoviesRatedByUser(userId: string): Observable<number> {
        return this.http.get<number>(this.baseUrl + "userrating/ratings/movieCount/" + userId);
    }
}