export class Rating {
    movieId: number;
    rating: number;
}

export class UserRating {
    userId: string;
    ratings: [Rating];
}