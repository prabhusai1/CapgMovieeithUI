import { NgModule } from '@angular/core';
import { MovieComponent } from './movie.component';
import { MovieCatalogComponent } from './movie-catalog.component';
import { UserRatingComponent } from './user-rating.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { movieRoutes } from './movie.routes';
import { HttpClientModule } from '@angular/common/http'

@NgModule({
    declarations: [
        MovieComponent,
        MovieCatalogComponent,
        UserRatingComponent
    ],
    imports: [
        BrowserModule,
        FormsModule,
        RouterModule.forChild(movieRoutes),
        HttpClientModule
    ],
    providers: []
})

export class MovieModule {

}