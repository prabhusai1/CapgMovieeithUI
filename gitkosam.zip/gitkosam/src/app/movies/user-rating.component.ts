import { Component } from '@angular/core';
import { MovieService } from './movie.service';

@Component({
    templateUrl: "./user-rating.component.html"
})
export class UserRatingComponent {
    userId: string;
    movieCount: number;

    constructor(private movieService: MovieService) { }

    getMovieCount() {
        this.movieService.getNoOfMoviesRatedByUser(this.userId).subscribe((data: number) => {
            console.log(data);
            this.movieCount = data;
        });
    }





}