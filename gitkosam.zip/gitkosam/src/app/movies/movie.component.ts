import { Component } from '@angular/core';
import { Movie } from './movie';
import { MovieService } from './movie.service';

@Component({
    templateUrl: "./movie.component.html"
})
export class MovieComponent {
    movieId: number;
    movie: Movie;

    constructor(private movieService: MovieService) { }

    getMovieDetails() {
        this.movieService.getMovieById(this.movieId).subscribe((data: Movie) => {
            this.movie = data;
        });
    }
}