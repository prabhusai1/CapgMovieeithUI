import { Routes } from '@angular/router';
import { MovieCatalogComponent } from './movie-catalog.component';
import { MovieComponent } from './movie.component';
import { UserRatingComponent } from './user-rating.component';


export const movieRoutes: Routes = [
    { path: "movieCatalog", component: MovieCatalogComponent },
    { path: "movie", component: MovieComponent },
    { path: "userRating", component: UserRatingComponent }
];

